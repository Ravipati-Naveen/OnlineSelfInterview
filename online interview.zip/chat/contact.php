<?php
// Include database connection
require_once 'config.php';

$message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $user_message = $_POST['message'];

    // Prepare SQL statement
    $sql = "INSERT INTO contact_submissions (name, email, message) VALUES (?, ?, ?)";
    
    try {
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $email, $user_message]);
        
        if ($stmt->rowCount() > 0) {
            $message = "Your message has been sent successfully!";
        } else {
            $message = "Oops! Something went wrong. Please try again later.";
        }
    } catch (PDOException $e) {
        $message = "Error: " . $e->getMessage();
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contact Us - Nandy Interview Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navbar (Same as other pages) -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">Nandy Interview</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php"><i class="fas fa-info-circle"></i> About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="domain_selection.php"><i class="fas fa-play"></i> Start Interview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Contact Us Content -->
    <div class="container mt-5 pt-5">
        <h1 class="text-center mb-5 animate__animated animate__fadeInDown">Contact Us</h1>
        
        <?php if (!empty($message)): ?>
            <div class="alert alert-info"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <div class="row animate__animated animate__fadeInUp">
            <div class="col-md-6 mb-4">
                <h2 class="mb-4">Get in Touch</h2>
                <form method="POST" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>">
                    <div class="mb-3">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" name="name" required>
                    </div>
                    <div class="mb-3">
                        <label for="email" class="form-label">Email</label>
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                    <div class="mb-3">
                        <label for="message" class="form-label">Message</label>
                        <textarea class="form-control" id="message" name="message" rows="5" required></textarea>
                    </div>
                    <button type="submit" class="btn btn-primary">Send Message</button>
                </form>
            </div>
            <div class="col-md-6 mb-4">
                <h2 class="mb-4">Our Location</h2>
                <div class="card">
                    <div class="card-body">
                        <h3 class="card-title h5">Malineni Lakshmaiah Women's Engineering College (MLEW)</h3>
                        <p class="card-text">
                            Pulladigunta (V),<br>
                            Guntur, Andhra Pradesh 522017<br>
                            India
                        </p>
                        <p class="card-text">
                            <strong>Phone:</strong> +91 863 2321900<br>
                            <strong>Email:</strong> info@mlewguntur.com<br>
                            <strong>Website:</strong> <a href="http://mlewguntur.com/" target="_blank">http://mlewguntur.com/</a>
                        </p>
                    </div>
                </div>
                <div class="mt-4">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3830.5669135243!2d80.41742731484943!3d16.25974498877052!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3a4a0a5b5c1c6e6d%3A0x5f8b8c8f8f8f8f8f!2sMallineni%20College%20of%20Engineering!5e0!3m2!1sen!2sin!4v1621234567890!5m2!1sen!2sin" width="100%" height="300" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer (Same as other pages) -->
    <footer>
        <div class="container">
            <p>&copy; 2023 Nandy Interview Platform. All rights reserved.</p>
            <div class="social-icons">
                <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin"></i></a>
                <a href="https://www.glassdoor.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-door-open"></i></a>
                <a href="https://www.indeed.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-search"></i></a>
                <a href="https://www.monster.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-briefcase"></i></a>
            </div>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
