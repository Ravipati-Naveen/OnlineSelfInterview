<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();

// Include the config file
require_once 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $domain = $_POST['domain'] ?? '';
    $answers = $_POST['answers'] ?? '';

    if (empty($domain) || empty($answers)) {
        die("Error: Missing required fields");
    }

    try {
        $stmt = $pdo->prepare("INSERT INTO interviews (domain, answers) VALUES (?, ?)");
        $stmt->execute([$domain, $answers]);
        
        echo "Interview submitted successfully!";
    } catch (PDOException $e) {
        die("Error: " . $e->getMessage());
    }
} else {
    die("Error: Invalid request method");
}