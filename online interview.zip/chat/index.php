<?php
session_start();
require_once 'config.php'; // Use require_once to ensure config.php is included

function isUserRegistered($email) {
    global $pdo; // Use the global $pdo connection
    try {
        $sql = "SELECT * FROM users WHERE email = ?";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$email]);
        return $stmt->rowCount() > 0;
    } catch (PDOException $e) {
        // Log the error or handle it appropriately
        error_log("Database error: " . $e->getMessage());
        return false;
    }
}

$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['start_interview'])) {
    $email = $_POST['email'];
    if (isUserRegistered($email)) {
        $_SESSION['user_email'] = $email;
        header("Location: domain_selection.php");
        exit();
    } else {
        $error_message = "You need to register first.";
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nandy Interview Platform</title>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.1.1/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="styles.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="#"><i class="fas fa-laptop-code"></i> Nandy Interview</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php"><i class="fas fa-info-circle"></i> About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <section class="hero">
        <div class="hero-content animate__animated animate__fadeIn">
            <h1>Welcome to Nandy Interview Platform</h1>
            <p>Empowering your career journey through innovative interviews</p>
            <a href="#start-journey" class="cta-button">Get Started</a>
        </div>
        <div class="hero-shapes">
            <div class="shape shape-1"></div>
            <div class="shape shape-2"></div>
            <div class="shape shape-3"></div>
        </div>
    </section>

    <div class="content-wrapper" id="start-journey">
        <div class="container">
            <div class="form-container animate__animated animate__fadeInUp">
                <h2><i class="fas fa-rocket"></i> Start Your Journey</h2>
                <form method="post" action="">
                    <input type="email" name="email" placeholder="Enter your email" required>
                    <input type="submit" name="start_interview" value="Start Interview">
                    <?php if (!empty($error_message)): ?>
                        <p class="error"><?php echo $error_message; ?></p>
                    <?php endif; ?>
                </form>
                <p class="register-link">Not registered yet? <a href="add_user.php">Register Now</a></p>
            </div>
        </div>
    </div>

    <section class="features">
        <div class="container">
            <h2 class="section-title" data-aos="fade-up">Why Choose Nandy Interview?</h2>
            <div class="feature-grid">
                <div class="feature-item" data-aos="fade-up" data-aos-delay="100">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-clock feature-icon"></i>
                            <h3>Time-Efficient</h3>
                        </div>
                        <div class="feature-back">
                            <p>Complete your interview at your own pace, saving time for both candidates and employers.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="200">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-globe feature-icon"></i>
                            <h3>Global Reach</h3>
                        </div>
                        <div class="feature-back">
                            <p>Connect with employers worldwide, breaking geographical barriers in your job search.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="300">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-chart-line feature-icon"></i>
                            <h3>Career Growth</h3>
                        </div>
                        <div class="feature-back">
                            <p>Gain valuable interview experience and improve your skills with each session.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="400">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-robot feature-icon"></i>
                            <h3>AI-Powered Insights</h3>
                        </div>
                        <div class="feature-back">
                            <p>Receive personalized feedback and suggestions powered by advanced AI algorithms.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="500">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-users feature-icon"></i>
                            <h3>Diverse Opportunities</h3>
                        </div>
                        <div class="feature-back">
                            <p>Access a wide range of job opportunities across various industries and sectors.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="600">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-shield-alt feature-icon"></i>
                            <h3>Secure Platform</h3>
                        </div>
                        <div class="feature-back">
                            <p>Enjoy a safe and confidential interview environment with our state-of-the-art security measures.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="700">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-comments feature-icon"></i>
                            <h3>Real-time Feedback</h3>
                        </div>
                        <div class="feature-back">
                            <p>Get instant feedback on your performance, helping you improve in real-time during the interview process.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="800">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-laptop-house feature-icon"></i>
                            <h3>Remote-friendly</h3>
                        </div>
                        <div class="feature-back">
                            <p>Perfect for remote job seekers and companies embracing distributed teams in the modern work environment.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="900">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-brain feature-icon"></i>
                            <h3>Skill Assessment</h3>
                        </div>
                        <div class="feature-back">
                            <p>Comprehensive skill assessment tools to help you identify your strengths and areas for improvement.</p>
                        </div>
                    </div>
                </div>
                <div class="feature-item" data-aos="fade-up" data-aos-delay="1000">
                    <div class="feature-card">
                        <div class="feature-front">
                            <i class="fas fa-handshake feature-icon"></i>
                            <h3>Employer Matching</h3>
                        </div>
                        <div class="feature-back">
                            <p>Our intelligent matching system connects you with employers that best fit your skills and career goals.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <section class="testimonial">
        <div class="container">
            <div class="testimonial-content animate__animated animate__fadeIn" data-aos="fade-in">
                <img src="https://randomuser.me/api/portraits/women/65.jpg" alt="User testimonial" class="testimonial-image">
                <blockquote>
                    "Nandy Interview Platform helped me land my dream job! The innovative approach to interviews made the process smooth and stress-free."
                </blockquote>
                <p class="testimonial-author">- Sarah Johnson, Software Engineer</p>
            </div>
        </div>
    </section>

    <section class="cta py-5">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-6 mb-4 mb-lg-0">
                    <h2 class="display-4 text-primary mb-3">Unlock Your Career Success</h2>
                    <p class="lead mb-4">Join thousands of professionals who have accelerated their careers with Nandy Interview Platform</p>
                    <a href="#start-journey" class="btn btn-primary btn-lg">Start Your Success Story</a>
                </div>
                <div class="col-lg-6">
                    <div class="position-relative">
                        <img src="https://images.unsplash.com/photo-1507679799987-c73779587ccf?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" alt="Career success" class="img-fluid rounded shadow">
                    </div>
                </div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <footer>
        <div class="container">
            <p>&copy; 2023 Nandy Interview Platform. All rights reserved.</p>
            <div class="social-icons">
                <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin"></i></a>
                <a href="https://www.glassdoor.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-door-open"></i></a>
                <a href="https://www.indeed.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-search"></i></a>
                <a href="https://www.monster.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-briefcase"></i></a>
            </div>
        </div>
    </footer>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/aos/2.3.4/aos.js"></script>
    <script>
        AOS.init({
            duration: 1000,
            once: true
        });
    </script>
</body>
</html>