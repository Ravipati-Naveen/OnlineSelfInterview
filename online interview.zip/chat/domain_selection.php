<?php
error_reporting(E_ALL);
ini_set('display_errors', 1);

session_start();
include 'config.php';

// Initialize variables
$domain = '';
$questionsArray = [];

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $domain = $_POST['domain'];
    $_SESSION['domain'] = $domain; // Store domain in session

    // Prepare questions based on the selected domain
    switch ($domain) {
        case "Software Development":
            $questionsArray = [
                'What programming languages do you know?',
                'Have you worked on any significant projects? Describe them.'
            ];
            break;
        case "Data Science":
            $questionsArray = [
                'What data analysis tools have you used?',
                'Can you describe a data project you have worked on?'
            ];
            break;
        case "Cyber Security":
            $questionsArray = [
                'What security protocols are you familiar with?',
                'Have you ever handled a security breach? Describe.'
            ];
            break;
        case "Cloud Computing":
            $questionsArray = [
                'What cloud platforms have you worked with?',
                'Describe a cloud migration project you have been involved in.'
            ];
            break;
        case "Artificial Intelligence":
            $questionsArray = [
                'What AI frameworks are you familiar with?',
                'Describe an AI project you have worked on.'
            ];
            break;
        default:
            $questionsArray = ['No questions available for the selected domain.'];
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nandy Interview Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="styles.css">
    <style>
        html, body {
            height: 100%;
            margin: 0;
        }
        body {
            display: flex;
            flex-direction: column;
        }
        .content {
            flex: 1 0 auto;
            padding-bottom: 60px; /* Adjust this value based on your footer height */
        }
        footer {
            flex-shrink: 0;
            width: 100%;
            background-color: #f8f9fa;
            padding: 20px 0;
        }
        #video-container {
            margin-top: 20px;
            text-align: center;
        }
        #questions-container {
            display: none;
            margin-top: 20px;
        }
        video {
            border: 1px solid #ddd;
            width: 320px;
            height: 240px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        #video-preview {
            display: none;
            border: 1px solid #ddd;
            width: 320px;
            height: 240px;
            object-fit: cover;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
        }
        button {
            margin: 5px;
        }
        #timer {
            font-size: 20px;
            margin-top: 10px;
            font-weight: bold;
            color: #4a90e2;
        }
        #popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background-color: #fff;
            border: 2px solid #ddd;
            padding: 20px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.2);
            z-index: 1000;
            border-radius: 10px;
        }
        #popup button {
            margin: 5px;
        }
        #overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 999;
        }
        .domain-card {
            transition: all 0.3s ease;
            cursor: pointer;
            overflow: hidden;
            position: relative;
        }
        .domain-card:hover {
            transform: translateY(-10px);
            box-shadow: 0 15px 30px rgba(0, 0, 0, 0.2);
        }
        .domain-card::before {
            content: '';
            position: absolute;
            top: -50%;
            left: -50%;
            width: 200%;
            height: 200%;
            background: rgba(255,255,255,0.1);
            transform: rotate(45deg);
            pointer-events: none;
            transition: all 0.7s ease;
        }
        .domain-card:hover::before {
            left: 100%;
        }
        .domain-card i {
            transition: all 0.3s ease;
        }
        .domain-card:hover i {
            transform: scale(1.2) rotate(360deg);
        }
        
        .btn-primary {
            position: relative;
            overflow: hidden;
            z-index: 1;
        }
        .btn-primary::after {
            content: '';
            position: absolute;
            bottom: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(255,255,255,0.2);
            border-radius: 50%;
            transform: scale(0);
            transition: transform 0.5s ease;
            z-index: -1;
        }
        .btn-primary:hover::after {
            transform: scale(2);
        }
        
        @keyframes float {
            0% { transform: translateY(0px); }
            50% { transform: translateY(-10px); }
            100% { transform: translateY(0px); }
        }
        .float-animation {
            animation: float 3s ease-in-out infinite;
        }
        
        .social-icons a {
            transition: all 0.3s ease;
        }
        .social-icons a:hover {
            transform: translateY(-5px) scale(1.1);
        }
        .edu-icon {
            width: 50px;
            height: 50px;
            object-fit: cover;
            border-radius: 50%;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }
        .edu-icon:hover {
            transform: scale(1.1);
        }
        .feature-item {
            text-align: center;
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php"><i class="fas fa-laptop-code"></i> Nandy Interview</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="about.php"><i class="fas fa-info-circle"></i> About</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="domain_selection.php"><i class="fas fa-play-circle"></i> Start Interview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
                    </li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Main Content -->
    <div class="content">
        <div class="container mt-5 pt-5">
            <?php if (!empty($domain)) : ?>
                <h1 class="text-center mb-4 animate__animated animate__fadeInDown" style="background: linear-gradient(45deg, #FF6B6B, #4ECDC4, #45B7D1); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Interview Questions for <?php echo htmlspecialchars($domain); ?></h1>
                <div id="video-container" class="animate__animated animate__fadeIn">
                    <p class="lead">To proceed, please grant access to your camera and microphone.</p>
                    <video id="video" autoplay class="mb-3"></video>
                    <video id="video-preview" controls class="mb-3"></video>
                    <button id="record-button" onclick="startRecording()" class="btn btn-primary"><i class="fas fa-record-vinyl"></i> Start Recording</button>
                    <button id="stop-button" onclick="stopRecording()" class="btn btn-danger" style="display: none;"><i class="fas fa-stop-circle"></i> Stop Recording</button>
                    <div id="questions-container" class="mt-4">
                        <div class="question-card animate__animated animate__fadeInUp">
                            <p id="question" class="h5"></p>
                            <div id="timer" class="mt-2"></div>
                        </div>
                        <form action="submit_form.php" method="post" id="interview-form">
                            <input type="hidden" name="domain" value="<?php echo htmlspecialchars($domain); ?>">
                            <input type="hidden" name="answers" id="answers" value="">
                            <button type="submit" id="submit-interview" class="btn btn-success mt-3" style="display: none;">Submit Interview</button>
                        </form>
                    </div>
                </div>
                <button id="start-interview" onclick="startInterview()" class="btn btn-lg btn-primary mt-3 animate__animated animate__pulse animate__infinite"><i class="fas fa-play-circle"></i> Start Interview</button>
            <?php else : ?>
             
                
                <!-- Educational Features Section -->
                <div class="row justify-content-center mb-5">
                    <div class="col-6 col-md-3 feature-item animate__animated animate__fadeInUp">
                        <img src="https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/solid/user-graduate.svg" alt="Learn" class="edu-icon">
                        <p>Learn from Experts</p>
                    </div>
                    <div class="col-6 col-md-3 feature-item animate__animated animate__fadeInUp animate__delay-1s">
                        <img src="https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/solid/comments.svg" alt="Practice" class="edu-icon">
                        <p>Practice Interviews</p>
                    </div>
                    <div class="col-6 col-md-3 feature-item animate__animated animate__fadeInUp animate__delay-2s">
                        <img src="https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/solid/chart-line.svg" alt="Feedback" class="edu-icon">
                        <p>Get Instant Feedback</p>
                    </div>
                    <div class="col-6 col-md-3 feature-item animate__animated animate__fadeInUp animate__delay-3s">
                        <img src="https://raw.githubusercontent.com/FortAwesome/Font-Awesome/6.x/svgs/solid/brain.svg" alt="Improve" class="edu-icon">
                        <p>Improve Your Skills</p>
                    </div>
                </div>
                <h1 class="text-center mb-4 animate__animated animate__fadeInDown" style="background: linear-gradient(45deg, #4A90E2, #50C878); -webkit-background-clip: text; -webkit-text-fill-color: transparent;">Select Your Domain</h1>

                <div class="row justify-content-center">
                    <div class="col-md-8">
                        <form method="post" action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" class="animate__animated animate__fadeInUp">
                            <div class="mb-3">
                                <label for="domain" class="form-label" style="color: #4A90E2;">Choose your area of expertise:</label>
                                <select id="domain" name="domain" class="form-select" required>
                                    <option value="">Select a domain</option>
                                    <option value="Software Development">Software Development</option>
                                    <option value="Data Science">Data Science</option>
                                    <option value="Cyber Security">Cyber Security</option>
                                    <option value="Cloud Computing">Cloud Computing</option>
                                    <option value="Artificial Intelligence">Artificial Intelligence</option>
                                </select>
                            </div>
                            <div class="text-center">
                                <button type="submit" class="btn btn-primary btn-lg animate__animated animate__pulse animate__infinite">Start Your Journey</button>
                            </div>
                        </form>
                    </div>
                </div>
                <div class="row mt-5">
                    <div class="col-md-4 col-sm-6 mb-4 animate__animated animate__fadeInUp animate__delay-1s">
                        <div class="card domain-card h-100 float-animation">
                            <div class="card-body text-center">
                                <i class="fas fa-code fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title h5">Software Development</h3>
                                <p class="card-text">Showcase your coding skills and problem-solving abilities.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4 animate__animated animate__fadeInUp animate__delay-2s">
                        <div class="card domain-card h-100 float-animation">
                            <div class="card-body text-center">
                                <i class="fas fa-chart-bar fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title h5">Data Science</h3>
                                <p class="card-text">Demonstrate your analytical skills and data-driven insights.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4 animate__animated animate__fadeInUp animate__delay-3s">
                        <div class="card domain-card h-100 float-animation">
                            <div class="card-body text-center">
                                <i class="fas fa-shield-alt fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title h5">Cyber Security</h3>
                                <p class="card-text">Prove your expertise in protecting digital assets and information.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4 animate__animated animate__fadeInUp animate__delay-4s">
                        <div class="card domain-card h-100 float-animation">
                            <div class="card-body text-center">
                                <i class="fas fa-cloud fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title h5">Cloud Computing</h3>
                                <p class="card-text">Show your skills in managing and leveraging cloud technologies.</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-4 col-sm-6 mb-4 animate__animated animate__fadeInUp animate__delay-5s">
                        <div class="card domain-card h-100 float-animation">
                            <div class="card-body text-center">
                                <i class="fas fa-brain fa-3x mb-3 text-primary"></i>
                                <h3 class="card-title h5">Artificial Intelligence</h3>
                                <p class="card-text">Demonstrate your knowledge in AI and machine learning techniques.</p>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Popup for download and close -->
    <div id="overlay"></div>
    <div id="popup" class="animate__animated animate__fadeIn">
        <h4 class="mb-3">Interview Completed!</h4>
        <p class="animate__animated animate__bounceIn">🎉 Congratulations on completing your interview! 🎊</p>
        <p class="animate__animated animate__fadeIn animate__delay-1s">You've nailed it! 🌟 Your recorded video is ready for download.</p>
        <div class="confetti-container animate__animated animate__zoomIn animate__delay-2s">
            <i class="fas fa-star text-warning"></i>
            <i class="fas fa-certificate text-success"></i>
            <i class="fas fa-award text-primary"></i>
        </div>
        <a id="download-link" download="recorded_video.webm" class="btn btn-primary mb-2"><i class="fas fa-download"></i> Download Video</a>
        <br>
        <button onclick="closePopup()" class="btn btn-secondary"><i class="fas fa-times"></i> Close</button>
    </div>

    <!-- Footer -->
    <footer class="py-3 mt-5" style="background-color: #f39c12;">
        <div class="container">
            <p class="text-center mb-0" style="color: #fff;">&copy; 2023 Nandy Interview Platform. All rights reserved.</p>
            <div class="text-center mt-2">
                <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer" class="text-white mx-2"><i class="fab fa-linkedin"></i></a>
                <a href="https://www.glassdoor.com" target="_blank" rel="noopener noreferrer" class="text-white mx-2"><i class="fas fa-door-open"></i></a>
                <a href="https://www.indeed.com" target="_blank" rel="noopener noreferrer" class="text-white mx-2"><i class="fas fa-search"></i></a>
                <a href="https://www.monster.com" target="_blank" rel="noopener noreferrer" class="text-white mx-2"><i class="fas fa-briefcase"></i></a>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/js/all.min.js"></script>
    <script>
        let mediaRecorder;
        let recordedChunks = [];
        let currentQuestionIndex = 0;
        let timer;
        const questionsArray = <?php echo json_encode($questionsArray); ?>;

        async function accessMedia() {
            try {
                const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
                const video = document.getElementById('video');
                video.srcObject = stream;
                video.style.display = 'block';

                // Initialize MediaRecorder
                mediaRecorder = new MediaRecorder(stream);
                mediaRecorder.ondataavailable = event => {
                    if (event.data.size > 0) {
                        recordedChunks.push(event.data);
                    }
                };
                mediaRecorder.onstop = () => {
                    const blob = new Blob(recordedChunks, { type: 'video/webm' });
                    const url = URL.createObjectURL(blob);
                    const videoPreview = document.getElementById('video-preview');
                    videoPreview.src = url;
                    videoPreview.style.display = 'block';
                    document.getElementById('download-link').href = url;
                    document.getElementById('download-link').download = 'recorded_video.webm';
                    showPopup(); // Show the popup when recording stops
                };
            } catch (err) {
                alert("Error accessing media devices: " + err.message);
            }
        }

        function startRecording() {
            if (mediaRecorder) {
                mediaRecorder.start();
                document.getElementById('record-button').style.display = 'none';
                document.getElementById('stop-button').style.display = 'inline';
            }
        }

        function stopRecording() {
            if (mediaRecorder) {
                mediaRecorder.stop();
                document.getElementById('record-button').style.display = 'inline';
                document.getElementById('stop-button').style.display = 'none';
            }
        }

        function startInterview() {
            document.getElementById('video-container').style.display = 'block';
            document.getElementById('start-interview').style.display = 'none';
            accessMedia();
            document.getElementById('questions-container').style.display = 'block';
            showQuestion();
        }

        function showQuestion() {
            if (currentQuestionIndex < questionsArray.length) {
                document.getElementById('question').innerText = questionsArray[currentQuestionIndex];
                startTimer();
            } else {
                // All questions completed, show submit button
                document.getElementById('submit-interview').style.display = 'inline-block';
                stopRecording(); // Stop recording when all questions are done
            }
        }

        function startTimer() {
            let timeLeft = 60; // 1 minute
            document.getElementById('timer').innerText = `Time left: ${timeLeft} seconds`;
            timer = setInterval(() => {
                timeLeft--;
                document.getElementById('timer').innerText = `Time left: ${timeLeft} seconds`;
                if (timeLeft <= 0) {
                    clearInterval(timer);
                    currentQuestionIndex++;
                    showQuestion();
                }
            }, 1000);
        }

        function showPopup() {
            document.getElementById('overlay').style.display = 'block';
            document.getElementById('popup').style.display = 'block';
        }

        function closePopup() {
            document.getElementById('popup').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
            // Optionally, stop the video and camera
            const video = document.getElementById('video');
            const stream = video.srcObject;
            if (stream) {
                let tracks = stream.getTracks();
                tracks.forEach(track => track.stop());
                video.srcObject = null;
            }
            document.getElementById('video-preview').style.display = 'none';
        }

        window.onload = function() {
            // Initially hide video container and questions container
            document.getElementById('video-container').style.display = 'none';
            document.getElementById('questions-container').style.display = 'none';
            document.getElementById('popup').style.display = 'none';
            document.getElementById('overlay').style.display = 'none';
        };

        // Add this new script for a typing effect on the main heading
        document.addEventListener('DOMContentLoaded', function() {
            const heading = document.querySelector('h1');
            const text = heading.textContent;
            heading.textContent = '';
            let i = 0;
            function typeWriter() {
                if (i < text.length) {
                    heading.textContent += text.charAt(i);
                    i++;
                    setTimeout(typeWriter, 100);
                }
            }
            typeWriter();
        });

        // Add this function to handle form submission
        document.getElementById('interview-form').addEventListener('submit', function(e) {
            e.preventDefault();
            const answers = JSON.stringify(recordedChunks);
            document.getElementById('answers').value = answers;
            this.submit();
        });
    </script>
</body>
</html>
