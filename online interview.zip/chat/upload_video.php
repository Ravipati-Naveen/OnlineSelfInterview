<?php
session_start();
include 'config.php'; // Ensure this file contains the database connection

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_FILES['video']) && $_FILES['video']['error'] == UPLOAD_ERR_OK) {
        $fileTmpPath = $_FILES['video']['tmp_name'];
        $fileName = $_FILES['video']['name'];
        $fileSize = $_FILES['video']['size'];
        $fileType = $_FILES['video']['type'];
        
        // Define upload path
        $uploadDir = 'uploads/';
        $destPath = $uploadDir . $fileName;

        // Move the file to the destination directory
        if (move_uploaded_file($fileTmpPath, $destPath)) {
            // Store video details in the database
            $stmt = $pdo->prepare("INSERT INTO videos (file_name, file_size, file_type, file_path, created_at) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$fileName, $fileSize, $fileType, $destPath]);
            
            echo 'Video uploaded and stored successfully.';
        } else {
            echo 'Error moving uploaded file.';
        }
    } else {
        echo 'Error uploading video.';
    }
} else {
    echo 'Invalid request method.';
}
?>
