<?php
// Include any necessary PHP logic here
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>About Us - Nandy Interview Platform</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <!-- Navbar (Same as other pages) -->
    <nav class="navbar navbar-expand-lg navbar-light bg-light fixed-top">
        <div class="container">
            <a class="navbar-brand" href="index.php">Nandy Interview</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item">
                        <a class="nav-link" href="index.php"><i class="fas fa-home"></i> Home</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link active" href="about.php"><i class="fas fa-info-circle"></i> About Us</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="domain_selection.php"><i class="fas fa-play"></i> Start Interview</a>
                    </li>
                    <li class="nav-item">
                        <a class="nav-link" href="contact.php"><i class="fas fa-envelope"></i> Contact</a>
                    </li>
                </ul>
                </ul>
            </div>
        </div>
    </nav>

    <!-- About Us Content -->
    <div class="container mt-5 pt-5">
        <h1 class="text-center mb-5 animate__animated animate__fadeInDown">About Nandy Interview Platform</h1>
        
        <div class="row align-items-center mb-5">
        <div class="col-md-6">
                <img src="https://images.unsplash.com/photo-1521737711867-e3b97375f902?ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8fA%3D%3D&auto=format&fit=crop&w=1000&q=80" alt="About Us" class="img-fluid rounded shadow">
            </div>
            <div class="col-md-6">
                <h2 class="mb-4">Our Mission</h2>
                <p>At Nandy Interview Platform, we're dedicated to revolutionizing the way professionals prepare for interviews. Our mission is to provide a cutting-edge, AI-powered platform that offers personalized interview experiences across various domains.</p>
                <p>We believe that practice makes perfect, and our platform is designed to give you the confidence and skills you need to ace your next interview.</p>
            </div>
        </div>

        <div class="row mb-5 animate__animated animate__fadeInUp animate__delay-1s">
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-robot fa-3x mb-3 text-primary"></i>
                        <h3 class="card-title h5">AI-Powered</h3>
                        <p class="card-text">Our advanced AI technology simulates real interview scenarios, providing a lifelike experience.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-chart-bar fa-3x mb-3 text-primary"></i>
                        <h3 class="card-title h5">Detailed Feedback</h3>
                        <p class="card-text">Receive comprehensive feedback on your performance, helping you identify areas for improvement.</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card h-100 shadow-sm">
                    <div class="card-body text-center">
                        <i class="fas fa-users fa-3x mb-3 text-primary"></i>
                        <h3 class="card-title h5">Community-Driven</h3>
                        <p class="card-text">Join a community of professionals and share experiences to grow together.</p>
                    </div>
                </div>
            </div>
        </div>

        <div class="text-center mb-5 animate__animated animate__fadeInUp animate__delay-2s">
            <h2 class="mb-4">Ready to Start Your Journey?</h2>
            <a href="domain_selection.php" class="btn btn-primary btn-lg">Begin Your Interview Practice</a>
        </div>
    </div>

    <!-- Footer (Same as other pages) -->
    <footer>
        <div class="container">
            <p>&copy; 2023 Nandy Interview Platform. All rights reserved.</p>
            <div class="social-icons">
                <a href="https://www.linkedin.com" target="_blank" rel="noopener noreferrer"><i class="fab fa-linkedin"></i></a>
                <a href="https://www.glassdoor.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-door-open"></i></a>
                <a href="https://www.indeed.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-search"></i></a>
                <a href="https://www.monster.com" target="_blank" rel="noopener noreferrer"><i class="fas fa-briefcase"></i></a>
            </div>
        </div>
    </footer>


    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
